#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * 描述
 *
 * @author CaoJing
 * @date ${YEAR}/${MONTH}/${DAY} ${HOUR}:${MINUTE}
 */
public enum ${NAME} {
}
